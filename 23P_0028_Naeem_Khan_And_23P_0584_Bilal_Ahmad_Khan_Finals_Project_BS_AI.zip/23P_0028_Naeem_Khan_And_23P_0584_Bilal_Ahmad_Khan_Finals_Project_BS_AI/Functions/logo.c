void logo() 
{
printf("\n\n");
printf("\t\t\t\t--  _____     ____   __     __             _        _\n");                      
printf("\t\t\t\t-- |  __ \\   / __ \\  \\ \\   / /     /\\     | |      ( )\n");                      
printf("\t\t\t\t-- | |__) | | |  | |  \\ \\_/ /     /  \\    | |      |/   ___\n");                 
printf("\t\t\t\t-- |  _  /  | |  | |   \\   /     / /\\ \\   | |          / __|\n");                
printf("\t\t\t\t-- | | \\ \\  | |__| |    | |     / ____ \\  | |____      \\__ \\\n");              
printf("\t\t\t\t-- |_|  \\_\\  \\____/     |_|    /_/    \\_\\ |______|     |___/\n");                
printf("\t\t\t\t--  _    _    ____     _____   _____    _____   _______              _\n");      
printf("\t\t\t\t-- | |  | |  / __ \\   / ____| |  __ \\  |_   _| |__   __|     /\\     | |\n");     
printf("\t\t\t\t-- | |__| | | |  | | | (___   | |__) |   | |      | |       /  \\    | |\n");     
printf("\t\t\t\t-- |  __  | | |  | |  \\___ \\  |  ___/    | |      | |      / /\\ \\   | |\n");     
printf("\t\t\t\t-- | |  | | | |__| |  ____) | | |       _| |_     | |     / ____ \\  | |____\n"); 
printf("\t\t\t\t-- |_|  |_|  \\____/  |_____/  |_|      |_____|    |_|    /_/    \\_\\ |______|\n\t\t\t\t--");
printf("\n\n");
} 

void Menu()
{
    printf("\n\n\n\t\t\t\t       __| |_____________________________________________________| |__\n");
    printf("\t\t\t\t       __   _____________________________________________________   __\n");
    printf("\t\t\t\t         | |                                                     | |\n");  
    printf("\t\t\t\t         | | __  __    _    ___ _   _   __  __ _____ _   _ _   _ | |\n");  
    printf("\t\t\t\t         | ||  \\/  |  / \\  |_ _| \\ | | |  \\/  | ____| \\ | | | | || |\n");  
    printf("\t\t\t\t         | || |\\/| | / _ \\  | ||  \\| | | |\\/| |  _| |  \\| | | | || |\n");  
    printf("\t\t\t\t         | || |  | |/ ___ \\ | || |\\  | | |  | | |___| |\\  | |_| || |\n");  
    printf("\t\t\t\t         | ||_|  |_/_/   \\_\\___|_| \\_| |_|  |_|_____|_| \\_|\\___/ | |\n");  
    printf("\t\t\t\t       __| |_____________________________________________________| |__\n");
    printf("\t\t\t\t       __   _____________________________________________________   __\n");
    printf("\t\t\t\t         | |                                                     | | \n"); 
}



void users()
{

    printf("\n\n\n1)  _    ____  __  __ ___ _   _ \t\t    2)    ____   _  _____ ___ _____ _   _ _____ \n");
    printf("   / \\  |  _ \\|  \\/  |_ _| \\ | | \t\t\t |  _ \\ / \\|_   _|_ _| ____| \\ | |_   _| \n");
    printf("  / _ \\ | | | | |\\/| || ||  \\| | \t\t\t | |_) / _ \\ | |  | ||  _| |  \\| | | | \n");
    printf(" / ___ \\| |_| | |  | || || |\\  | \t\t\t |  __/ ___ \\| |  | || |___| |\\  | | | \n");
    printf("/_/   \\_\\____/|_|  |_|___|_| \\_|\t\t\t |_| /_/   \\_\\_| |___|_____|_| \\_| |_|  \n");
}


int separator()
{
    printf("\n*************************************************\n");
    return 0;
}
int statement()
{
    printf("\nSelect a Doctor you want to make appointment with:\n");
    return 0;
}

void showDepartments()
{
    printf("\nSelect a Department\n");
    printf("\n1.Cardiology\t\t2.Internal Medicine\n3.Neurology\t\t4.Orthopedics\n5.Nephrology\t\t6.Urology\n7.General Surgery\t8.Radiology");
    printf("\n9.Opthalmology\t\t10.Obstetric and Gynaecology\n11.Dermatology\t\t12.Pediatrics\n13.Emergency Medicine\t14.Gastroenterology");
    printf("\n15.Anesthesiology\t16.Surgery\n17.Rheumatology\t\t18.Hematology\n19.Physiotheraphy\t20.Pathology\n21.Pulmonology");
    printf("\t\t22.Neurosurgery\n23.Medicine\t\t24.Otorhinolaryngogly");
}

