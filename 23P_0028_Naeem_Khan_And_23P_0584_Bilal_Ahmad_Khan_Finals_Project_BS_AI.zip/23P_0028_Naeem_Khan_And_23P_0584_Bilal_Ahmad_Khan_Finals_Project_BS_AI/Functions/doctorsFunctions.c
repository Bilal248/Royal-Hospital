void timeSwitch(int Time);
int Timings;
char Timing[50];
char *timing = Timing;//Making time a pointer to be used in other functions

void dr_Kashif()
{

DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_Farooq()
{
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ilyas() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_mehmood() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_asaf() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_laiba() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_huma() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_bakhtiyar() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_fatima() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_maryam() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_naeem() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_bilal() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_abbas() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_saqib() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_balaj() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_haroon() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_kifayat() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_arsam() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_Saif() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_Rafi() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_Malaika() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_Mahnoor() {
    DocTime();
    printf("\nSelect Timing:");
    scanf("%d", &Timings);
    timeSwitch(Timings);
}

void dr_ahmad() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ismail() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_raqeeb() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_saad() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ushna() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_hussain() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_usman() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ijaz() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_maaz() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_zain() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_hamas() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_zuhair() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_hafeez() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_imad() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_arslan() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_muzzamil() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_sohaib() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ali() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_haseeb() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_sheryar() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_mohsin() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_mansoor() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ibrahim() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_aftab() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_salman() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_anees() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_wajid() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ashfaq() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_adnan() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_faiz() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_zimad() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_mahnoor() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ayesha() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_hammad() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_khushi() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_atif() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_shabir() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_naveed() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_waheed() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_izhar() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_samira() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_sara() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_safiya() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_noor() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_zahid() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}


void dr_wajahat() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_rauf() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_wahab() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_shahid() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_amir() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_shawal() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_hasnat() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_azan() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_asad() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_benazir() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_imran() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_suleiman() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ayaz() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_murad() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_sana() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_momin() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}

void dr_ikram() {
DocTime();
printf("\nSelect Timing:");
scanf("%d",&Timings);
timeSwitch(Timings);
}
