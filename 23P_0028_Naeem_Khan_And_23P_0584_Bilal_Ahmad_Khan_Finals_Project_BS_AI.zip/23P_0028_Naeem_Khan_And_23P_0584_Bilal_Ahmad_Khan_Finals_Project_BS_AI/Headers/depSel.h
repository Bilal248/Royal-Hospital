//Function for Storing the selected department name
void depSel(int department,char *Department)
{
if(department == 1)
{
    strcpy(Department, "Cardiology");
}

if (department == 2)
{
    strcpy(Department, "Internal Medicine");
}

if (department == 3)
{
    strcpy(Department, "Neurology");
}

if (department == 4)
{
    strcpy(Department, "Orthopedics");
}

if (department == 5)
{
    strcpy(Department, "Nephrology");
}

if (department == 6)
{
    strcpy(Department, "Urology");
}

if (department == 7)
{
    strcpy(Department, "General Surgery");
}

if (department == 8)
{
    strcpy(Department, "Radiology");
}

if (department == 9)
{
    strcpy(Department, "Opthalmology");
}

if (department == 10)
{
    strcpy(Department, "Obstetric And Gynaecology");
}

if (department == 11)
{
    strcpy(Department, "Dermatology");
}

if (department == 12)
{
    strcpy(Department, "Pediatrics");
}

if (department == 13)
{
    strcpy(Department, "Emergency Medicine");
}

if (department == 14)
{
    strcpy(Department, "Gastroenterology");
}

if (department == 15)
{
    strcpy(Department, "Anesthesiology");
}

if (department == 16)
{
    strcpy(Department, "Surgery");
}

if (department == 17)
{
    strcpy(Department, "Rheumatology");
}

if (department == 18)
{
    strcpy(Department, "Hematology");
}

if (department == 19)
{
    strcpy(Department, "Physiotheraphy");
}

if (department == 20)
{
    strcpy(Department, "Pathology");
}

if (department == 21)
{
    strcpy(Department, "Pulmonology");
}

if (department == 22)
{
    strcpy(Department, "Neurosurgery");
}

if (department == 23)
{
    strcpy(Department, "Medicine");
}

if (department == 24)
{
    strcpy(Department, "Otorhinolaryngogly");
}

}
